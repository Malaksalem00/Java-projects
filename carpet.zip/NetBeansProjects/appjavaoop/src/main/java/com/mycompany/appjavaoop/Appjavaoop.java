/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.appjavaoop;

/**
 *
 * @author Hassan Kwaik
 */
public class Appjavaoop {

    public static void main(String[] args) {
       Studant s1=new Studant();
       Studant s2=new Studant();
       Studant s3=new Studant();
       s1 .insert(1 , "ali", 95.4);
       s2 .insert(2, "ahmad", 93.2);
       s3 .insert(3, "malak", 94.4);
       s1. updataGrade(92.0);
       s1.display();
       s2.display();
       s3.display();
    }
}
