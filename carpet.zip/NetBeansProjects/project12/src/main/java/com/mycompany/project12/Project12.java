/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project12;

import java.util.Scanner;

/**
 *
 * @author Hassan Kwaik
 */
public class Project12 {

    public static void main(String[] args) {
       Scanner k = new Scanner(System.in);

       
        System.out.print("Enter the temperature in Fahrenheit: ");
        double fahrenheit = k.nextDouble();

     
        Temperature temp = new Temperature(fahrenheit);

      
        System.out.println("\nTemperature in Fahrenheit: " + temp.getFahrenheit() + "°F");
        System.out.println("Temperature in Celsius: " + temp.getCelsius() + "°C");
        System.out.println("Temperature in Kelvin: " + temp.getKelvin() + "K");
    }
}
