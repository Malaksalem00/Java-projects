/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.exam;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Malak salem abo kwaik
 * ID :2320234786
 */
public class Exam {

    public static void main(String[] args) {
        ArrayList<Book> books = new ArrayList<>();
        Scanner k = new Scanner(System.in);
        while (true) {
            System.out.println(" Choose an  Optins \n 1-Add A book \n 2- Search for a book \n 3- Edit book data "
                    + "\n 4- Printing more than 200 books"
                    + "\n 5- Exit"
                    + "\n Youe optins");
            int choice = k.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter ID store:");
                    int Id = k.nextInt();
                    k.nextLine();
                    System.out.println("Enter the name of the store:");
                    String names = k.nextLine();
                    
                  System.out.println("Enter the city of store:");
                    String City = k.nextLine();
                    System.out.println("Enter the price book:");
                    int Price = k.nextInt();
                    System.out.println("Enter the number of author:");
                    int author = k.nextInt();
                    System.out.println(" Enter the number of books:");
                    int numBooks = k.nextInt();
                    System.out.println("Enter the department (1. culuer ,2. social)");
                    int dep = k.nextInt();
                    books.add(new Book(Id, names,City ,Price, author, numBooks, dep));
                    System.out.println("books added successfully");

                    break;
                case 2:
                    System.out.println("Enter the number of author");
                    int searchId = k.nextInt();

                    for (int i = 0; i < books.size(); i++) {
                        Book book = books.get(i);
                        if (book.getAuther() == searchId);
                        {
                            System.out.println("The book has been found \n" + book);

                            
                        }
                    } break;
                case 3:
                    System.out.println("Enter the number of author");
                    int editId = k.nextInt();
                    for (int i = 0; i < books.size(); i++) {
                        Book book = books.get(i);
                        if (book.getAuther() == editId);
                        {
                            System.out.println("The new number books is:");
                            int newNumber = k.nextInt();
                            System.out.println("New Department (1- cultuer,2- social)");
                            int newDept = k.nextInt();
                            book.setNumber_of_book(newNumber);
                            book.setDepartment(newDept);
                            System.out.println("The book has been successfly modified");
                            
                        }
                    }  break;
                case 4:
                    boolean found = false;
                    for (int i = 0; i < books.size(); i++) {
                        Book book = books.get(i);
                        if (book.getNumber_of_book() > 200) {
                            System.out.println("Book" + book.getName() + "Number of books" + book.getNumber_of_book());
                            found = true;
                        }
                        if (!found) {
                            System.out.println("There are no books with more than 200 copies");
                        }
                    }
                case 5:
                    System.out.println(" Exited");
                    break;

                default:
                    System.out.println("In correct choice");
            }
        }
    }
}//@author Malak salem abo kwaik
 //* ID :2320234786
