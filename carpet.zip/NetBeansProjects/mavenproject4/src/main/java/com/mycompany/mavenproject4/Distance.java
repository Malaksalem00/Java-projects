/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject4;

/**
 *
 * @author Hassan Kwaik
 */
public class Distance {

    private int feet;
    private int inches;

    public Distance() {
        feet = 0;
        inches = 0;
    }

    public Distance(int f, int i) {
        feet = f;
        inches = i;
    }

    public void display() {
        System.out.println("Distance: " + feet + " feet " + inches + " inches");
    }

}
