/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author Hassan Kwaik
 */
public class Thing {
  private int x;
  private int y;
  private static int z=0;
  public void putThing(){
      x=z;
      y=z;
  }
  public static void putThing(int a){
     z=a;
  }

    @Override
    public String toString() {
        return "Thing{" + "x=" + x + ", y=" + y + '}';
    }
  
}
