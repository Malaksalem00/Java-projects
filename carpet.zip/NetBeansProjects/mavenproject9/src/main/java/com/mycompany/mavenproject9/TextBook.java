/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject9;

/**
 *
 * @author Hassan Kwaik
 */
public class TextBook {
   private String title;
   private String auther;
   private String publisher;
   public TextBook ( String textTitle, String auth, String Pub ){
       title =textTitle;
       auther= auth;
       publisher=Pub;
   }
   public TextBook(TextBook object2){//Copy constructor
       title=object2.title;
       auther=object2.auther;
       publisher=object2.publisher;
   }
   public void set ( String textTitle,String auth,String Pub){
       title=textTitle;
       auther=auth;
       publisher=Pub;
   }
   

    @Override
    public String toString() {
         String str = "Title :"+title +
                "\nAuther :"+auther +
                "\nPublisher :"+publisher;
        return str;
    }
   
}
