/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.carpetcalculator;

/**
 *
 * @author malak salem abukwaik
 * ID: 230234786
 */
public class RoomCarpet {
    private  RoomDimension size;
    private double carpetCost;
    public RoomCarpet(RoomDimension dim,double cost){
        this.size=dim;
        this.carpetCost=cost;
    }
        public double getTotaleCost(){
           return size.getArea()*carpetCost;
        }

    @Override
    public String toString() {
        return size.toString()+ 
                "\n Carpet Cost =" + carpetCost + 
                "\n Totale Carpet Cost $" + getTotaleCost();
    }
        
    
}
/**
 *
 * @author malak salem abukwaik
 * ID: 230234786
 */