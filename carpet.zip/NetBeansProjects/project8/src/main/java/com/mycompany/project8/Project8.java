/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project8;

/**
 *
 * @author Hassan Kwaik
 */
public class Project8 {

    public static void main(String[] args) {
       PersonalInformation p1 = new PersonalInformation("Malak Salem", "Khan Younis, Palestine", 20, "0597878628");
        PersonalInformation p2 = new PersonalInformation("Ali Ahmed", "Gaza, Palestine", 23, "0598123486");
        PersonalInformation p3 = new PersonalInformation("Mona Khaled", "Rafah, Palestine", 24, "0598764432");

        // Display the personal information for each person
        System.out.println("Person 1 Information:\n" + p1.toString() + "\n");
        System.out.println("Person 2 Information:\n" + p2.toString() + "\n");
        System.out.println("Person 3 Information:\n" + p3.toString() + "\n");
    }
}
