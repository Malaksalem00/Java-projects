/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject5;

/**
 *
 * @author Hassan Kwaik
 */
public class Mavenproject5 {

    public static void main(String[] args) {
       Bank savings = new Bank(6000, 0.04,"Savings");
       Bank checking = new Bank(3000, 0.05, "Checking");
       Bank moneyMarket= new Bank(11000, 0.07, "Money Market");
     savings.printAccountDetails();
     System.out.println();
     checking.printAccountDetails();
        System.out.println();
        moneyMarket.printAccountDetails();
        
    }
}
