/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javaoop;

/**
 *
 * @author Hassan Kwaik
 */
public class Account {

    private int accountNO;
    private String name;
    private float amount;

    //123    ali   50
    public void insert(int a, String n, float amt) {
        this.accountNO = a;
        this.name = n;
        this.amount = amt;
    }

    public void deposit(float amt) {//100 
        this.amount = this.amount
                + amt;
        System.out.println(amt + "deposit");
    }

    public void withdraw(float amt) {
        if (amount < amt) {
            System.out.println("Insufficient Balance");
        } else {
            this.amount = this.amount
                    - amt;
            System.out.println(amt + "withdraw");
        }}
    
    /**
     *
     */
    public void checkBalance(){
        System.out.println("Balance=" + this.amount);
    }

  
    public String toString() {
        return "Account{" + "accountNO=" + accountNO + ", name=" + name + ", amount=" + amount + '}';
    }
    
    
    
}
