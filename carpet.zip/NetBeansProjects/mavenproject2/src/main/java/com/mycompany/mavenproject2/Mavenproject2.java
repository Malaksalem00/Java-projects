/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject2;

import java.util.Scanner;

/**
 *
 * @author Hassan Kwaik
 */
public class Mavenproject2 {

    public static void main(String[] args) {
        Scanner k=new Scanner (System.in);
        System.out.println("Enter a raduis");
        double r=k.nextDouble();       
        Circle c =new Circle(r);
        System.out.println("the area=" + c.getArea());
        System.out.println( "the Diameter=" + c.getDiameter());
        System.out.println( "the Circumference" + c.getCircumference());
        
    }
}
