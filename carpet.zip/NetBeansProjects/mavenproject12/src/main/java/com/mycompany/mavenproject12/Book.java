/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject12;

/**
 *
 * @author Malak abu kwaik
 * id :2320234786
 */
public class Book  extends Store{
    private int auther;
    private int Number_of_book;
    private int Department;

    public Book() {
    }

    public Book(int id, String name, String city,int price,int auther, int Number_of_book, int Department) {
        super(id, name, city, price);
        this.auther = auther;
        this.Number_of_book = Number_of_book;
        this.Department = Department;
    }

    public int getAuther() {
        return auther;
    }

    public void setAuther(int auther) {
        this.auther = auther;
    }

    public int getNumber_of_book() {
        return Number_of_book;
    }

    public void setNumber_of_book(int Number_of_book) {
        this.Number_of_book = Number_of_book;
    }

    public int getDepartment() {
        return Department;
    }

    public void setDepartment(int Department) {
        this.Department = Department;
    }
     public double getprice(double price){
        switch (Department) {
            case 1:
                return price*0.8;
            case 2:
                return price*0.92;
            default:
                return price;
        }
     }

    @Override
    public String toString() {
        return super.toString() 
                + ", Number of Books:" +Number_of_book +" Department: "+ (Department==1 ? "Cultural" :"Social")+ 
                "price after discount"+ getPrice();
    }
     
    

   
    
}
