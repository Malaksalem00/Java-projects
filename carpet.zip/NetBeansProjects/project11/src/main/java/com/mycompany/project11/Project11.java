/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project11;

import java.util.Scanner;

/**
 *
 * @author Hassan Kwaik
 */
public class Project11 {

    public static void main(String[] args) {
        Scanner K = new Scanner(System.in);

        // طلب إدخال الدرجات من المستخدم
        System.out.print("Enter the first test score: ");
        double score1 = K.nextDouble();

        System.out.print("Enter the second test score: ");
        double score2 = K.nextDouble();

        System.out.print("Enter the third test score: ");
        double score3 = K.nextDouble();

        // إنشاء كائن من فئة TestScores
        TestScore testScores = new TestScore(score1, score2, score3);

        // عرض الدرجات والمتوسط الحسابي
        System.out.println("\nTest Scores Information:\n");
        System.out.println(testScores.toString());

        
    }

    
}
