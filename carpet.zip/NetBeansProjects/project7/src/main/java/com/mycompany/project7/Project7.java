/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project7;

/**
 *
 * @author Hassan Kwaik
 */
public class Project7 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
