/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.driver;

/**
 *
 * @author Malak Kwaik
 * ملك سالم خليل ابو كويك 
 * 2320234786
 */
public class Account {

    private String name;
    private double balance;
    private static double yearlyInterestRate;



   
    public Account(String name, double balance) {
        this.name = name;
        if (balance > 0) {
            this.balance = balance;
        } else {
            System.out.println("The Balance  is less than or euqle zero");
            this.balance = 5000.0;
        }
    }
public Account() {
        this("MyAccount", 5000.0);
    
    }

    public void setBalance(double balance) {
        if (balance > 0) {
            this.balance = balance;
        } else {
            System.out.println(" The Insufficient balance”");
        }

    }

    public void withdrow(double amount) {
        if (balance >= amount) {
           balance-=amount;
            System.out.println(name+"withdraw:"+amount + "the new balance:"+balance);
        } else {
                System.out.println("Insufficient balance or invalid amount for " + name);
        }
    }
    public void deposit(double depositAmount) { 
        if (depositAmount>0){
            balance+=depositAmount;
        System.out.println(name+"deposit:"+depositAmount + "the new balance:"+balance);
        }
    }
    
    //دالة لحساب الفائدة الشهرية وإضافتها إلى الرصيد
    public void calculateMonthlyInterest(){
         double monthlyInterest = balance * yearlyInterestRate / 12;
        balance += monthlyInterest;
    
}
//دالة ثابتة لتعديل نسبة الفائدة السنوية
     public static void modifyYearlyInterestRate(double newRate) {
        if (newRate >= 0) {
            yearlyInterestRate = newRate;
            
        } else {
            System.out.println(" Interest rate must be positive.");

        }
     }

    public double getBalance() {
      return balance;
    } 

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
       
    
     @Override
    public String toString() {
        return "Account{" + "name:" + name + ", balance:" + balance + '}';
    }

    
}





    
