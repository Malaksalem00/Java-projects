/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.driver;

import java.util.ArrayList;


/**
 *
 * @author Malak Kwaik
 * ملك سالم خليل ابو كويك 
 * 2320234786
 */
public class Driver {
    
    public static void main(String[] args) {
//        


        // إنشاء ArrayList لتخزين الحسابات
        ArrayList<Account> accounts = new ArrayList<>();
        
     
        Account acc1 = new Account(); // الحساب الأول بالقيم الافتراضية
        Account acc2 = new Account("UserAccount", 10000.0); // الحساب الثاني برصيد 

        // إضافة الحسابات إلى ArrayList
        accounts.add(acc1);
        accounts.add(acc2);
         Account.modifyYearlyInterestRate(0.05);
        // حساب الفائدة الشهرية لمدة 12 شهرًا لكل الحسابات في القائمة
        for (int i = 1; i <=12; i++) {
            for (int j=0;j<accounts.size();j++) {
                acc1.calculateMonthlyInterest();
                acc2.calculateMonthlyInterest();
            }
        }

        // طباعة الأرصدة بعد 12 شهرًا لكل الحسابات
        System.out.println("Balances after 12 months with 5% annual interest rate:");
        System.out.println(acc1);
         System.out.println(acc2);
        
        
        
//        }
System.out.println("تنفيذ عمليات السحب والايداع");
        
              
              acc1.deposit(1000);
              acc2.withdrow(10000);    

        // تعديل نسبة الفائدة السنوية إلى 10% وإعادة حساب الفائدة لمدة 12 شهرًا
        Account.modifyYearlyInterestRate(0.10);
        for (int i = 1; i <= 12; i++) {
                for (int j=0;j<accounts.size();j++) {
                    acc1.calculateMonthlyInterest();
                    acc2.calculateMonthlyInterest();
                }
        }
System.out.println("Balances after 12 months with 10% annual interest rate:");
      System.out.println(acc1);
         System.out.println(acc2);
        
        
    }
}



       
  


    
    

