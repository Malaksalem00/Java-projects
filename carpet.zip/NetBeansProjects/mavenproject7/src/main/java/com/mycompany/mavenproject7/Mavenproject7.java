/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject7;

/**
 *
 * @author Hassan Kwaik
 */
public class Mavenproject7 {

    public static void main(String[] args) {
       Pet myPet = new Pet();
       myPet.setName("Buddy");
       myPet.setAnimal("Dog");
       myPet.setAge(3);
        System.out.println("Pet Name:" + myPet.getName());
        System.out.println("Pet Animal:" + myPet.getAnimal());
        System.out.println("Pet Age:" + myPet.getAge());
    }
}
