/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject6;

/**
 *
 * @author Hassan Kwaik
 */
public class Mavenproject6 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
