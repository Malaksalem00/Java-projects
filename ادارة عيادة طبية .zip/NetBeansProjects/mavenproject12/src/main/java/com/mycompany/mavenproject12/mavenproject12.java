/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject12;

//import java.util.ArrayList;
//import java.util.Scanner;

/**
 *
 * @author Hassan Kwaik
 */
public class mavenproject12 {

    

    public static void main(String[] args) {
//        ArrayList<Book> books=new ArrayList<>();
//        Scanner k= new Scanner(System.in);
//        do {            
            System.out.println("""
                               Choose an  Optins 
                                Add A book 
                                Search for a book 
                                Edit book data 
                                Printing more than 200 books 
                                Exit
                                Youe optins""");
            
//                      } while (true);
//            int choice=  k.nextInt();
//            switch(choice){
//                case 1 : System.out.println("Enter the number of author ");
//                int author =k.nextInt();
//                    System.out.println(" Enter the number of books");
//                    int numBooks=k.nextInt();
//                    System.out.println("Enter the department (1. culuer ,2. social)");
//                    int department=k.nextInt();
//                   
//                    System.out.println("books added successfully");
//                    break;
//                case 2: System.out.println("Enter the number of author for search him");
//                int searchAuther=k.nextInt();
                
//            }
//        } while (true);
//        
              
        }
 
        }
  
