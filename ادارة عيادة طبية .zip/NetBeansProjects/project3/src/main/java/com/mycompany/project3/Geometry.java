/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project3;

/**
 *
 * @author malak Kwaik
 */
public class Geometry {

    
public  static double getCircleArea( double r){
    if (r<0){
        System.out.println("نصف القطر لايمكن ان يكون سالبا");
        return -1;
    }
   return Math.PI*Math.pow(r, 2);
    }
public static  double getRectangleArea( int w, int l){
    if(l<0||w<0){
        System.out.println("الطول والعرض لا يمكن ان يكونوا سالبين");
        return -1;
    }
   return w * l;
    }
public static  double getTriangleArea( double b,int h){
    if(b<0||h<0){
        System.out.println("القاعدة والارتفاع لا يمكن ان يكونوا سالبين");
        return -1;
    }
   return 0.5 * b * h;
    }

}

