/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

/**
 *
 * @author Hassan Kwaik
 */
public class Mavenproject1 {

    public static void main(String[] args) {
//        for(int N = 1 ; N<=5 ; ++N){
//        System.out.println(N+"\t"+(N*10)+"\t"+(N*100)+"\t"+(N*1000));
  //      }
  
  Thing one =new Thing();
  Thing two = new Thing();
  Thing three = new Thing();
   Thing.putThing(5);
  
  
    }
}
