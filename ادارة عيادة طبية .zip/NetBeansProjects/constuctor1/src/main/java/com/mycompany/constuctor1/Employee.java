/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.constuctor1;

/**
 *
 * @author Hassan Kwaik
 */
public class Employee {

    public static void main(String[] args) {
        Employee1 e1 = new Employee1("malak", 6);
        Employee1 e2 = new Employee1("mena", 5);
        Employee1 e3 = new Employee1();
        System.out.println(e3.getDepartment());
    }
}
