/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalproject1;

import java.io.Serializable;


/**
 *@author Malak abo Kwaik
 * Name: Malak Salem AbuKwaik
 * ID :2320234786
 */
 
public class Booking implements Serializable{
    private String id,  details;
    private String date;
    private int depar; // 1-3
    private Doctor other;
    private Patient object;

    public Booking(String id, String date, String details, int depar, Doctor other, Patient object) {
        this.id = id;
        this.date = date;
        this.details = details;
        this.depar = depar;
        Doctor other1 =new Doctor(other);
        Patient object1 =new Patient(object);
        
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getDepart() {
        return depar;
    }

    public void setDepart(int depar) {
        this.depar = depar;
    }

    public Doctor getOther() {
        return other;
    }

    public void setOther(Doctor other) {
        this.other = other;
    }

    public Patient getObject() {
        return object;
    }

    public void setObject(Patient object) {
        this.object = object;
    }

    

    @Override
    public String toString() {
        return "[Booking]" + "id=" + id + ", details=" + details + ", date=" + date + ", department=" + depar + ", doctor=" + other.name + ", patient=" + object.name ;
    }
    

    
    
}


