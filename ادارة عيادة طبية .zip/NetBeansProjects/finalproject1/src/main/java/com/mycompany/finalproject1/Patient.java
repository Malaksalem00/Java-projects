/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalproject1;

import java.io.Serializable;


    /**
 *
 * @author Malak abo Kwaik
 * Name: Malak Salem AbuKwaik
 * ID :2320234786
 */
public class Patient extends Person implements Serializable{
    private int numberOfBookings;

    public Patient() {
    }

    public Patient(int numberOfBookings, String name, String Address, String email, String gender, String id, String phoneNumber) {
        super(name, Address, email, gender, id, phoneNumber);
        this.numberOfBookings = numberOfBookings;
    }

   
    public Patient(Patient Object){
        this(Object.numberOfBookings,Object.name,Object.Address,Object.email,Object.gender,Object.id,Object.phoneNumber);
    }

   public Patient(String name, String Address, String email,String gender, String id, String phoneNumber) {
  super(name, Address, email, gender, id, phoneNumber);
  
    }

    public int getNumberOfBookings() {
        return numberOfBookings;
    }

    public void setNumberOfBookings(int numberOfBookings) {
        this.numberOfBookings = numberOfBookings;
    }
       public void increasingBooking(){
           numberOfBookings++;
       }
       public void decrasingBooking(){
           if (numberOfBookings > 0){
           numberOfBookings--;
       }
       }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
       

    @Override
    public String toString() {
        return "[patient]" + super.toString()+ "numberOfBookings=" + numberOfBookings ;
    }
       
}
