/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalproject1;

import java.io.Serializable;



/**
 *
 * @author Malak abo Kwaik
 * Name: Malak Salem AbuKwaik
 * ID :2320234786
 */
public class Doctor extends Employee implements Serializable{
  private int completedBookings;
  private int department; // 1 - General, 2 - Pediatrician, 3 - Psychiatrist

   public Doctor(int completedBookings, int deprtment, double basicSalary, String hireDate, String name, String Address, String email, String gender, String id, String phoneNumber){
   super(basicSalary,hireDate, name, Address, email, gender, id, phoneNumber);
    this.completedBookings=completedBookings;
    this.department=department;
   
   }

   
    public Doctor(int completedBookings, int department, double basicSalary, double liveExpensive, String hireDate, String address, String email1, String gender1, String id1, String phone) {
        super(basicSalary, liveExpensive, hireDate);
        this.completedBookings = completedBookings;
        this.department = department;
    }

    public Doctor(int completedBookings, int department, double basicSalary, double liveExpensive, String hireDate, String name, String Address, String email, String gender, String id, String phoneNumber) {
        super(basicSalary, liveExpensive, hireDate, name, Address, email, gender, id, phoneNumber);
        this.completedBookings = completedBookings;
        setDepartment(department);
    }

    
    public Doctor(Doctor other){
    super(other.basicSalary,other.hireDate,other.name,other.Address,other.email,other.gender,other.id,other.phoneNumber);
    this.completedBookings=other.completedBookings;
    this.department=other.department;
    }

   
    public int getCompletedBookings() {
        return completedBookings;
    }

    public void setCompletedBookings(int completedBookings) {
        this.completedBookings = completedBookings;
    }

    
    public double getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public double getLiveExpensive() {
        return liveExpensive;
    }

    public void setLiveExpensive(double liveExpensive) {
        this.liveExpensive = liveExpensive;
    }

    public String getHireDate() {
        return hireDate;
    }

    public void setHireDate(String hireDate) {
        this.hireDate = hireDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

  @Override
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    

    public void setDepartment(int department) {
        if (department >= 1 && department <= 3) 
            this.department = department;
        else System.out.println("Invalid department. Must be 1(General),2(pediatrician),3(Psychiatrist)");
    }
    public int  getDepartment() {
        return department;
    }
public String getDepartmentName() {
    switch ( getDepartment()) {
        case 1: return "General";
        case 2: return "Pediatrician";
        case 3: return "Psychiatrist";
        default: return "Unknown";
    }
}

    @Override
    public double getSalary() {
        return basicSalary + getLiveExpensive() + (2 * completedBookings);
    }

    @Override
    public String toString() {
        
        return "[Doctor]"+ super.toString()+
                 " , completedBookings=" + completedBookings + ", department=" + getDepartmentName() ;
    }

    
    }

  
    
    

