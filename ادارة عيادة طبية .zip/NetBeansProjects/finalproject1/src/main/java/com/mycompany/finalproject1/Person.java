/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalproject1;

import java.io.Serializable;

/**
 *
 * @author Malak abo Kwaik
 * Name: Malak Salem AbuKwaik
 * ID :2320234786
 * 
 */
public class Person  implements Serializable{
    protected String name,Address,email,gender,id ,phoneNumber;
   

    public Person() {
    }

    public Person(String name, String Address, String email, String gender, String id, String phoneNumber) {
        this.name = name;
        this.Address = Address;
        this.email = email;
        this.gender = gender;
        this.id = id;
        this.phoneNumber = phoneNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    @Override
    public String toString() {
        return  "name=" + name + ", Address=" + Address + ", email=" + email + ", gender=" + gender + ", id=" + id + ", phoneNumber=" + phoneNumber + '}';
    }
   
  
}
