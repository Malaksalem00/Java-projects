/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.finalproject1;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.util.ArrayList;

import java.util.Scanner;


/**
 *
 * @author Malak abo Kwaik 
 * Name: Malak Salem AbuKwaik 
 * ID:2320234786
 */
public class Finalproject1 {//Clinic Management
static Manager manager;
    static ArrayList<Doctor> doctors = new ArrayList<>();
    static ArrayList<Patient> patients = new ArrayList<>();
    static ArrayList<Booking> bookings = new ArrayList<>();
    public static void main(String[] args) throws ParseException {
        Scanner input = new Scanner(System.in);
        
int choice;
      do {
            
                System.out.println("\n===== Medical Clinic Management System =====");
                System.out.println("1. Add Employee (Manager/Doctor)");
                System.out.println("2. Add Patient");
                System.out.println("3. Add Booking");
                System.out.println("4. Show Doctor (General/All)");
                System.out.println("5. Show Bookings for Patient");
                System.out.println("6. Show Employee Salaries");
                System.out.println("7. Delete Booking");
                System.out.println("8. Count Bookings for Patient");
                System.out.println("9. Save Data to File");
                System.out.println("10. Exit");
                System.out.print("Enter your choice (1-10): ");
                
                 choice = input.nextInt();
                switch (choice) {
                    case 1:
                        addEmployeeMenu(input);
                        break;
                    case 2:
                        Patient p = createPatient(input);
                        patients.add(p);
                        break;
                    case 3:
                        addBooking(input);
                        break;
                    case 4:
                        showDoctorMenu(input);
                        break;
                    case 5:
                        showBookingsForPatient(input);
                        break;
                    case 6:
                        showSalariesMenu(input);
                        break;
                    case 7:
                        deleteBooking(input);
                        break;
                    case 8:
                        countBookings(input);
                        break;
                    case 9:
                        saveData();
                        break;
                    case 10:
                        System.out.println("Exiting Program");
                        break;
                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            }while(choice != 10);
        }

    private static void addEmployeeMenu(Scanner input) throws ParseException {
        int ch;
//دالة عامة ثابتة لا ترجع قيمة وتستقبل annerعشان تقرا ادخال المستخدم
    
   do{
        System.out.println("\n--- Add Employee ---");
        System.out.println("1. Add Manager");
        System.out.println("2. Add Doctor");
        System.out.println("3. Back to main menu");
        System.out.print("Enter choice: ");
         ch = input.nextInt();
        switch (ch) {
            case 1:
                manager = createManager(input);
                break;
            case 2:
                doctors.add(createDoctor(input));
                input.nextLine();
                System.out.println("Do you want to repeat the process and add another doctor?");
                String answer = input.next();
                if (answer.equals("yes")) {
                    continue;
                } else {
                    break;
                }
            case 3:
                
                break ;
            default:
                System.out.println("Invalid input. Try again.");
                break;
        }
    }while(ch != 3);
    }
private static Doctor createDoctor(Scanner input) throws ParseException {
   input.nextLine();
   try{
            System.out.print("Enter name: ");
            String names = input.nextLine();

            System.out.print("Enter ID: ");
            String idD = input.nextLine();

            System.out.print("Enter address: ");
            String address = input.nextLine();

            System.out.print("Enter phone: ");
            String phone = input.nextLine();

            System.out.print("Enter email: ");
            String emaill = input.nextLine();

            System.out.print("Enter gender: ");
            String gend = input.nextLine();

            System.out.print("Enter basic salary: ");
            double basicSalary1 = input.nextDouble();

            input.nextLine();
            System.out.print("Enter hire date  ");////
            String dateStr = input.nextLine();
           
            

            System.out.print("Enter completed bookings: ");
           int booking = input.nextInt();

            System.out.print("Enter department (1-General, 2-Pediatrician, 3-Psychiatrist): ");
            int dept = input.nextInt();
            while (dept < 1 || dept > 3) {//"ضل عيد السؤال عليه لحد ما يدخل رقم من 1 إلى 3"
                System.out.print("Invalid department. Enter again (1-3): ");
                dept = input.nextInt();
            }


            return new Doctor(booking, dept, basicSalary1, dateStr, names, address, emaill, gend, idD, phone);
   } catch (Exception e) {
            System.out.println("Error in input. Try again.");
            return null;
        }
    }

    


    private static Manager createManager(Scanner input) {
     try {
            input.nextLine(); // تنظيف السطر
            System.out.print("Enter name: ");
            String names = input.nextLine();

            System.out.print("Enter ID: ");
            String idP = input.nextLine();

            System.out.print("Enter address: ");
            String address = input.nextLine();

            System.out.print("Enter phone: ");
            String phone = input.nextLine();

            System.out.print("Enter email: ");
            String emaill = input.nextLine();

            System.out.print("Enter gender: ");
            String gend = input.nextLine();

            System.out.print("Enter basic salary: ");
            double basicSalaryes = input.nextDouble();

            input.nextLine(); // تنظيف السطر بعد double
            System.out.print("Enter hire date (yyyy/MM/dd): ");
            String dateStr = input.nextLine();
            
            System.out.print("Enter bonus: ");
            double bonues = input.nextDouble();

            return new Manager(bonues, basicSalaryes,dateStr , names, address, emaill, gend, idP, phone);
        } catch (Exception e) {
            System.out.println("Error in input. Try again." + e.getMessage());
            return null;
        }
    }
//    
    

    private static Patient createPatient(Scanner input) {
        try {
            input.nextLine();
            System.out.print("Enter name: ");
            String name = input.nextLine();

            System.out.print("Enter ID: ");
            String id = input.nextLine();

            System.out.print("Enter address: ");
            String address = input.nextLine();

            System.out.print("Enter phone: ");
            String phone = input.nextLine();

            System.out.print("Enter email: ");
            String email = input.nextLine();

            System.out.print("Enter gender: ");
            String gender = input.nextLine();

            return new Patient(name, address, email, gender,id, phone);
        } catch (Exception e) {
            System.out.println("Error in input. Try again.");
            return null;
        }
    }
 
  
    
    private static void addBooking(Scanner input) throws ParseException {
        input.nextLine();
        do {
            System.out.println("--- Add Booking ---");

            System.out.println("Available Doctors:");
            for (Doctor d : doctors) {
                System.out.println("ID: " + d.getId() + ", Name: " + d.getName());
                
            }

            System.out.println("Available Patients:");
            for (Patient p : patients) {
                System.out.println("ID: " + p.getId() + ", Name: " + p.getName());
             
            }

            System.out.print("Enter Doctor ID: ");//البحث عن الطبيب 
            String docId = input.nextLine();
            Doctor selectedDoctor = null;
            for (Doctor d : doctors) {
                if (d.getId().equals(docId)) {
                    selectedDoctor = d;
                    break;
                }
            }
            
            if (selectedDoctor == null) {
                System.out.println("Doctor not found. Try again.");
                continue;
            }

            System.out.print("Enter Patient ID: ");
            String patId = input.nextLine();
            Patient selectedPatient = null;
            for (Patient p : patients) {
                if (p.getId().equals(patId)) {
                    selectedPatient = p;
                    break;
                }
            }
            

            if (selectedPatient == null) {
                System.out.println("Patient not found. Try again.");
                continue;
            }

            System.out.print("Enter Booking ID: ");
            String bookId = input.nextLine();

            System.out.print("Enter Booking Date: ");

           String dateStr = input.nextLine();
            

            System.out.print("Enter Booking Details: ");
            String details = input.nextLine();

            int dept = selectedDoctor.getDepartment();//تم الحصول على رقم القسم الذي يعمل فيه الطبيب المحدد (selectedDoctor) ويتم تخزينه في متغير اسمه dept.
            
            Booking b = new Booking(bookId, dateStr, details, dept, selectedDoctor, selectedPatient);
            bookings.add(b);
            selectedDoctor.setCompletedBookings(selectedDoctor.getCompletedBookings() + 1);//يتم زيادة عدد الحجوزات المكتملة للطبيب بمقدار 1.

            selectedPatient.increasingBooking();

            System.out.println("Booking added successfully!");

            System.out.print("Do you want to add another booking? (yes/no): ");
            String again = input.nextLine();
            if (!again.equalsIgnoreCase("yes")) {//ذا كانت الإجابة ليست "y" (بأي شكل: Y أو y)، يتم الخروج من الحلقة (loop) باستخدام break.
                break;
            }
        }while(true);
    }

    private static void showDoctorMenu(Scanner input) {
        
    while (true) {
        System.out.println("\n--- Show Doctor ---");
        System.out.println("1. General Doctor Employees");
        System.out.println("2. All Doctors");
        System.out.println("3. Back to main menu");
        System.out.print("Enter choice: ");
        int ch = input.nextInt();

        switch (ch) {
            case 1: showGeneralDoctors(); break;
            case 2: showAllDoctors(); break;
            case 3: return;
            default: System.out.println("Invalid input. Try again.");
        }
    }
}

    static void showAllDoctors() {
    if (doctors.isEmpty()) {
        System.out.println("No doctors available.");
        return;
    }
    System.out.println("\n--- All Doctors ---");
    for (Doctor d : doctors)
        System.out.println(d);
}

static void showGeneralDoctors() {
    System.out.println("\n--- General Doctors ---");
    for (Doctor d : doctors) {
        if (d.getDepartment()==1) {
            System.out.println(d);
        
    }else{
                 System.out.println("No general doctors found.");
}
}}


    private static void showBookingsForPatient(Scanner input) {
          input.nextLine();
        do {
            System.out.println("Available patient");
          for (Patient p : patients) System.out.println(p.getId() + " - " + p.getName());
            System.out.print("Enter Patient ID: ");
            String id = input.nextLine();
            Patient pat = null;
            for (Patient p : patients) if (p.getId() != null && p.getId().equals(id)) pat = p;
            if (pat == null) { System.out.println("Not found."); continue; }

            int count = 0;
            for (Booking b : bookings) if (b.getObject() != null && b.getObject().equals(pat)) {
                System.out.println(b);
                count++;//عدد الحجوزات للمريض
            }
            System.out.println("Total bookings: " + bookings.size());

            System.out.print("Show another? (y/n): ");
            String answer = input.nextLine();
                if (answer.equalsIgnoreCase("yes")) {
                    continue;
                } else {
                    break;
                }
        }while(true);
    
            }
    

    private static void showSalariesMenu(Scanner input) {
        
        while (true) {
            System.out.println("\n--- Show Salaries ---");
            System.out.println("1. Manager salary");
            System.out.println("2. Specific Doctor salary");
            System.out.println("3. Back to main menu");
            System.out.print("Enter choice: ");
             int opt = input.nextInt(); 
             input.nextLine();
        if (opt == 1 && manager != null) {
            System.out.println("Manager salary: " + manager.getSalary());
        } else if (opt == 2) {
            System.out.print("Enter Doctor ID: ");
            String id = input.nextLine();
            for (Doctor d : doctors)
                if (d.getId().equals(id)){
                    System.out.println("Salary: " + d.getSalary());
                } 
        }else if (opt == 3) {
                break;
            } else {
                System.out.println("Invalid input. Try again.");
        }
    }
        }
   
    private static void deleteBooking(Scanner input) {
       while (true) {
            for (Booking b : bookings) System.out.println(b.getId() + ", " + b.getDepart());
            System.out.print("Enter booking ID to delete: ");
            String id = input.nextLine();
            Booking toRemove = null;
            for (Booking b : bookings) if (b.getId().equals(id)) toRemove = b;
            if (toRemove != null) {//للحذف
                bookings.remove(toRemove);
                toRemove.getObject().decrasingBooking();//لحذف حجز
                System.out.println("Booking deleted.");
                
            } else System.out.println("Not found");

            System.out.print("Delete another? (yes/no): ");
            String answer = input.nextLine();
                if (answer.equalsIgnoreCase("yes")) {
                    continue;
                } else {
                    break;
                }
            
        }
    }
    

    private static void countBookings(Scanner input) {
     input.nextLine();
    while (true) {
        System.out.println("--- Count Bookings for Specific Patient ---");

        if (patients.isEmpty()) {
            System.out.println("No patients available.");
            return;
        }

        System.out.println("Available Patients:");
        for (Patient p : patients)
            System.out.println("ID: " + p.getId() + ", Name: " + p.getName());

        System.out.print("Enter Patient ID: ");
        String patId = input.nextLine();

        Patient selected = null;// نبحث عن مريض بالـ ID المدخل.
   // إذا وجدناه: نحفظه في المتغير selected

   // إذا لم نجده: يبقى null
     
        for (Patient p : patients) {
            if (p.getId().equals(patId)) {
                selected = p;
                break;
            }
        }

        while (selected == null) {
            System.out.print("Invalid ID. Enter existing Patient ID: ");
            patId = input.nextLine();
            
        }

        System.out.println("Patient: " + selected.getName());
        System.out.println("Total Bookings: " + selected.getNumberOfBookings());

        System.out.print("Do you want to count bookings for another patient? (y/n): ");
        String again = input.nextLine();
        if (!again.equalsIgnoreCase("y")) break;
    }

}
    

    private static void saveData() {
     try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("clinic_data.dat"))) {
        out.writeObject(manager);
        out.writeObject(doctors);
        out.writeObject(patients);
        out.writeObject(bookings);
        System.out.println("Data saved successfully to clinic_data.dat");
    } catch (IOException e) {
        System.out.println("Error saving data: " + e.getMessage());
    }   
    }
}
    
    
    

   
    
