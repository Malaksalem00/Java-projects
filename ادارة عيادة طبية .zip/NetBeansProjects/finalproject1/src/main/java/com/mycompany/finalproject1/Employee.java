/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalproject1;




/**
 *
 * @author Malak abu Kwaik
 *  Name: Malak Salem AbuKwaik
 * ID :2320234786
 */
public abstract class Employee extends Person {
    protected double basicSalary,liveExpensive;
    protected  String hireDate;

    public Employee() {
        super();
   
    }

    public Employee(double basicSalary, double liveExpensive,  String hireDate) {
        this.basicSalary = basicSalary;
        this.liveExpensive = liveExpensive;
        this.hireDate = hireDate;
    }

    public Employee(double basicSalary, double liveExpensive, String hireDate, String name, String Address, String email, String gender, String id, String phoneNumber) {
        super(name, Address, email, gender, id, phoneNumber);
        this.basicSalary = basicSalary;
        this.liveExpensive = liveExpensive;
        this.hireDate = hireDate;
    }
    public Employee(double basicSalary, String hireDate, String name, String Address, String email, String gender, String id, String phoneNumber) {
        super(name, Address, email, gender, id, phoneNumber);
        this.basicSalary = basicSalary;
        
        this.hireDate = hireDate;
    }
    
    public double getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public double getLiveExpensive() {
        return basicSalary *0.055;
    }

    public void setLiveExpensive(double liveExpensive) {
        this.liveExpensive = liveExpensive;
    }

    public String getHireDate() {
        return hireDate;
    }

    public void setHireDate(String hireDate) {
        this.hireDate = hireDate;
    }

    @Override
    public String toString() {
        return super.toString()+
         "basicSalary=" + basicSalary +  ", hireDate=" + hireDate ;
    }
    public abstract double getSalary();
    
}
