/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.application;



/**
 *
 * @author Hassan Kwaik
 */
public class Application {

    public static void main(String[] args) {
        
        
        
        
        
        
        
        
        
    }}
        /*  Scanner in=new Scanner(System.in);
          System.out.println("Enter your number");
          int num;
        int arr []={1,3,5,7};
             num=in.nextInt();
             boolean found=false;//give a defult is false
      
        for( int i=0;i<arr.length;++i){// start with loop
        if(arr [i]==num){//if the number entered  by the user is eqle to the valu of the array
            found=true; //اذا تم العثور على الرقم يتم تعيين المتغير
            //foundال true ويتم ايقاف الحلقة 
            break;
        }
        
        }
           if(found){
                System.out.println("found");
           }
                else{
               System.out.println(" not found");
                   }// اذا كان صحيحا يتم طباعة الfound واذا لم يتم العثور على الرقم يتم طباعة not found
         
        
        لنعين اكبر قيمة واصغر قيمة
        int arr[] = {5, 7, 9, 3, -5};
        int min = Integer.MAX_VALUE;
        int max = Intint min = Integer.MAX_VALUE;eger.MIN_VALUE;
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] < min) {
                min = arr[i];
            }
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        System.out.println("max=" + max);
        System.out.println("min=" + min);
    }

}
*//*
      int arr[] = {5, 7, 9, 3, -5};  
      Arrays.sort(arr);
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr [i]+" ");
        }
            
        }
    }
*/