/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.employee;

import java.util.Scanner;



/**
 *
 * @author Hassan Kwaik
 */
public class Employee {

    public static void main(String[] args) {
        

        Employee2 e1 = new Employee2("Susan Meyers", 47899, "Accounting", "Vice President");
          Employee2 e2 = new Employee2("Mark Jones", 39119, "IT", "Programmer");
        Employee2 e3 = new Employee2("Joy Rogers", 81774, "Manufacturing", "Engineer");
        System.out.println("Employee 1 Information:\n"+ e1.toString());
    
    System.out.println("Employee 2 Information:\n" + e2.toString());
   
    System.out.println("Employee 3 Information:\n"+ e3.toString());
        

    }
}
