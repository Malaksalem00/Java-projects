/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project10;

/**
 *
 * @author Hassan Kwaik
 */
public class Payroll {
    private String name;
    private int id;
    private double hourlyPayRate;
    private double hoursWorked;
    public  Payroll(String n,int id){
        this.name = n;
        this.id = id;
        this.hourlyPayRate = 0.0; 
        this.hoursWorked = 0.0; 
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getHourlyPayRate() {
        return hourlyPayRate;
    }

    public void setHourlyPayRate(double hourlyPayRate) {
        this.hourlyPayRate = hourlyPayRate;
    }

    public double getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(double hoursWorked) {
        this.hoursWorked = hoursWorked;
    }
     public double calculateGrossPay() {
        return hourlyPayRate * hoursWorked;
     }
     @Override
    public String toString() {
        return "Employee Name: " + name + "\n" +
               "Employee ID: " + id + "\n" +
               "Hourly Pay Rate: $" + hourlyPayRate + "\n" +
               "Hours Worked: " + hoursWorked + "\n" +
               "Gross Pay: $" + calculateGrossPay();
    }
}
