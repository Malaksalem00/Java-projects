/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.carpetcalculator;

/**
 *
 * @author malak salem abukwaik
 * ID: 230234786
 */
public class RoomDimension {
     private double lenght;
     private double width;
     public RoomDimension(double len,double w){
         lenght=len;
         width=w;
        
     }
     public double getArea(){
         return lenght*width;
         
     }

    @Override
    public String toString() {
        return "RoomDimension" + "lenght=" + lenght + ", width=" + width + ", Area=" + getArea();
    }
     
}
/**
 *
 * @author malak salem abukwaik
 * ID: 230234786
 */