/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.carpetcalculator;

import java.util.Scanner;

/**
 *
 * @author malak salem abukwaik
 * ID: 230234786
 */
public class CarpetCalculator {

    public static void main(String[] args) {
     Scanner k =new Scanner(System .in);
        System.out.println("Enter the Room Length (feet):");//ادخال طول الغرفة  من قبل المستخدم
        double length;
        length=k.nextDouble();
        System.out.println("Enter the Room Width (Feet):");//ادخال عرض الغرفة من قبل المسخدم
         double width;
        width=k.nextDouble();
        RoomDimension roomsize=new RoomDimension(length, width);//لانشاء  فئة لحساب المساحة
        System.out.println("Enter carpet price per square foot :"); // ادخال سعر السجاد لكل متر مربع 
        double price;
        price=k.nextDouble();
        RoomCarpet carpet=new RoomCarpet(roomsize, price);//حساب التكلفة الاجمالية  
        System.out.println("\n" +carpet);// عرض التكلفة الاجمالية 
        
        
        
    }
}
/**
 *
 * @author malak salem abukwaik
 * ID: 230234786
 */