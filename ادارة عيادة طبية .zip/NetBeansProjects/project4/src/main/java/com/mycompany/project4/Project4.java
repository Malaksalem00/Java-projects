/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project4;

import java.util.Scanner;

/**
 *
 * @author Hassan Kwaik
 */
public class Project4 {

    public static void main(String[] args) {
        Scanner k=new Scanner(System.in);
        System.out.println("enter the number of month 1-12");
        int month=k.nextInt();
        System.out.println("enter the number of year");
        int year=k.nextInt();
        if (month<12){
        MonthDays A=new MonthDays(month,year);
        System.out.println(A.getNumberOfDays());
        }
        else System.out.println("error");
    }
}
