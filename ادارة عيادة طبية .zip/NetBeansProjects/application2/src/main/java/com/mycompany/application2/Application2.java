/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.application2;
import java.io.*;
import java.util.ArrayList;

/**
 *
 * @author Hassan Kwaik
 */
public class Application2 {

//  static int min(int n1, int n2, int n3) {
//      int min = n1;
//        if (min > n2) {
//            min = n2;
//        }
//        if (min > n3) {
//            min = n3;
//        }
//        return min;
//    }
//   static int avareg(int n1,int n2, int n3){
//       int sum= n1+n2+n3;
//       int result=sum/3;
//       return result;
//   }
//
  public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
      FileOutputStream file=new FileOutputStream("file.dat");
      ObjectOutputStream out =new ObjectOutputStream(file);
      int a=5;
      int [] Array={10,20,30};
      ArrayList<student> s1 = new ArrayList<>();
      s1.add(new student(1,"malak"));
      s1.add(new student(2,"king"));
//              student[] s=new student[3];
//              s[0]=new student(1, "malak");
//              s[1]=new student(2,"king");
      String name ="malak";
      out.writeInt(a);
      out.writeObject(Array);
      out.writeObject(s1);
      out.writeUTF(name);
      out.close();
      ObjectInputStream in = new ObjectInputStream( new FileInputStream("file.dat"));
        System.out.println( in.readInt());
        int [] a1 = (int []) in.readObject();
        for( int i=0;i<a1.length;i++){
            System.out.println(a1[i]);
        }
        ArrayList<student> s2 = (ArrayList<student>) in .readObject();
        for(int i=0;i<s2.size();i++){
            System.out.println( s2.get(i));
        }
      
      System.out.println( in.readUTF());
      
      in.close();
      
  }}
      
//       System.out.println("Enter 3 number");  ;
              
//       Scanner input=new Scanner(System.in);
//       int num1,num2,num3;
//       System.out.println("Enter number 1:");
//       num1=input.nextInt();
//       System.out.println("Enter number 2:"); 
//        num2=input.nextInt();
//       System.out.println("Enter number 3:");
//        num3=input.nextInt();
////        System.out.println("the avareg is :"+ (avareg(num1, num2, num3)));
        
   

    
//        System.out.println("Enter 3 number");
//        Scanner input = new Scanner(System.in);
//        int num1, num2, num3;
//
//        System.out.println("Enter number one");
//        num1 = input.nextInt();
//        System.out.println("Enter number two");
//        num2 = input.nextInt();
//        System.out.println("Enter number three");
//        num3 = input.nextInt();
//
//        System.out.println("the smallest among number is :"+ (min(num1, num2, num3)));
//    }


