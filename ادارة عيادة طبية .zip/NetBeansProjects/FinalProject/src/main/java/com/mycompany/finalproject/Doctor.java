/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalproject;

import java.util.Date;

/**
 *
 * @author Malak abo Kwaik
 * Name: Malak Salem AbuKwaik
 * ID :2320234786
 */
public class Doctor extends Employee{
  private int completedBookings;
  private int department; // 1 - General, 2 - Pediatrician, 3 - Psychiatrist

    public Doctor() {
    }

    public Doctor(int completedBookings, int department, double basicSalary, double liveExpensive, Date hireDate) {
        super(basicSalary, liveExpensive, hireDate);
        this.completedBookings = completedBookings;
        this.department = department;
    }

    public Doctor(int completedBookings, int department, double basicSalary, double liveExpensive, Date hireDate, String name, String Address, String email, String gender, String id, String phoneNumber) {
        super(basicSalary, liveExpensive, hireDate, name, Address, email, gender, id, phoneNumber);
        this.completedBookings = completedBookings;
        this.department = department;
    }

    public Doctor(int completedBookings, int department, double basicSalary, Date hireDate, String name, String Address, String email, String gender, String id, String phoneNumber) {
        super(basicSalary, hireDate, name, Address, email, gender, id, phoneNumber);
        this.completedBookings = completedBookings;
        this.department = department;
    }
    public Doctor(Doctor other){
    this(other.completedBookings,other.department,other.basicSalary,other.hireDate,other.name,other.Address,other.email,other.gender,other.id,other.phoneNumber);
    }

   
    public int getCompletedBookings() {
        return completedBookings;
    }

    public void setCompletedBookings(int completedBookings) {
        this.completedBookings = completedBookings;
    }

    public int getDepartment() {
        return department;
    }

    public void setDepartment(int department) {
        if (department >= 1 && department <= 3) 
            this.department = department;
        else throw new IllegalArgumentException("Invalid department");
    }
    @Override
    public double getSalary() {
        return basicSalary + getLiveExpensive() + (2 * completedBookings);
    }

    @Override
    public String toString() {
        
        return "[Doctor]" +super.toString()+ "completedBookings=" + completedBookings + ", department=" + department ;
    }

  
    
    
}
