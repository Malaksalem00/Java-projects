/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalproject;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author @author Malak abo Kwaik
 * Name: Malak Salem AbuKwaik
 * ID :2320234786
 */
public class Booking  implements Serializable{
    private String id,  details;
    private Date date;
    private int department; // 1-3
    private Doctor doctor;
    private Patient patient;

    public Booking(String id, Date date, String details, int department, Doctor doctor, Patient patient) {
        this.id = id;
        this.date = date;
        this.details = details;
        this.department = department;
        this.doctor = doctor;
        this.patient = patient;
        
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getDepartment() {
        return department;
    }

    public void setDepartment(int department) {
        this.department = department;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    @Override
    public String toString() {
        return "[Booking]" + "id=" + id + ", details=" + details + ", date=" + date + ", department=" + department + ", doctor=" + doctor.name + ", patient=" + patient.name ;
    }
    

    
    
}
