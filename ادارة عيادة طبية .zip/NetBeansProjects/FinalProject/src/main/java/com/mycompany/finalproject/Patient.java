/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalproject;

/**
 *
 * @author Malak abo Kwaik
 * Name: Malak Salem AbuKwaik
 * ID :2320234786
 */
public class Patient extends Person{
    private int numberOfBookings;

    public Patient() {
    }

    public Patient(int numberOfBookings, String name, String Address, String email, String gender, String id, String phoneNumber) {
        super(name, Address, email, gender, id, phoneNumber);
        this.numberOfBookings = numberOfBookings;
    }

   
    public Patient(Patient Object){
        this(Object.numberOfBookings,Object.name,Object.Address,Object.email,Object.gender,Object.id,Object.phoneNumber);
    }

   public Patient(String name, String address, String email, String gender, String phone) {
   
    }

    public int getNumberOfBookings() {
        return numberOfBookings;
    }

    public void setNumberOfBookings(int numberOfBookings) {
        this.numberOfBookings = numberOfBookings;
    }
       public void increasingBooking(){
           numberOfBookings++;
       }
       public void decrasingBooking(){
           if (numberOfBookings > 0){
           numberOfBookings--;
       }
       }

    @Override
    public String toString() {
        return "[Patient]" +super.toString()+ "numberOfBookings=" + numberOfBookings ;
    }
       
}
