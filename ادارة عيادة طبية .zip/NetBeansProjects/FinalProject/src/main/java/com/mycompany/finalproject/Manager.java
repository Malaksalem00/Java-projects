/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalproject;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author Malak abu Kwaik
 *  Name: Malak Salem AbuKwaik
 * ID :2320234786
 */
public class Manager extends Employee{
private double bouns;

    public Manager() {
    }

    public Manager(double bouns, double basicSalary, double liveExpensive, Date hireDate) {
        super(basicSalary, liveExpensive, hireDate);
        this.bouns = bouns;
    }

    public Manager(double bouns, double basicSalary, double liveExpensive, Date hireDate, String name, String Address, String email, String gender, String id, String phoneNumber) {
        super(basicSalary, liveExpensive, hireDate, name, Address, email, gender, id, phoneNumber);
        this.bouns = bouns;
    }

    public Manager(double bouns, double basicSalary, Date hireDate, String name, String Address, String email, String gender, String id, String phoneNumber) {
        super(basicSalary, hireDate, name, Address, email, gender, id, phoneNumber);
        this.bouns = bouns;
    }

    public double getBouns() {
        return bouns;
    }

    public void setBouns(double bouns) {
        this.bouns = bouns;
    }

   
    @Override
    public double getSalary() {
     return basicSalary +getLiveExpensive()+bouns;
    }

    @Override
    public String toString() {
      
        return "[Manager]" +super.toString() + "bouns: " + bouns + "TotalSalary :" + getSalary();
    } 
    
    
    
}
