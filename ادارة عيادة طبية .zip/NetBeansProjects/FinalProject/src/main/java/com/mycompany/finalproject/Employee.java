/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalproject;


import java.util.Date;

/**
 *
 * @author Malak abu Kwaik
 *  Name: Malak Salem AbuKwaik
 * ID :2320234786
 */
public abstract class Employee extends Person {
    protected double basicSalary,liveExpensive;
    protected  Date hireDate;

    public Employee() {
        super();
   
    }

    public Employee(double basicSalary, double liveExpensive,  Date hireDate) {
        this.basicSalary = basicSalary;
        this.liveExpensive = liveExpensive;
        this.hireDate = hireDate;
    }

    public Employee(double basicSalary, double liveExpensive, Date hireDate, String name, String Address, String email, String gender, String id, String phoneNumber) {
        super(name, Address, email, gender, id, phoneNumber);
        this.basicSalary = basicSalary;
        this.liveExpensive = liveExpensive;
        this.hireDate = hireDate;
    }
    public Employee(double basicSalary, Date hireDate, String name, String Address, String email, String gender, String id, String phoneNumber) {
        super(name, Address, email, gender, id, phoneNumber);
        this.basicSalary = basicSalary;
        
        this.hireDate = hireDate;
    }
    
    public double getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public double getLiveExpensive() {
        return basicSalary *0.055;
    }

    public void setLiveExpensive(double liveExpensive) {
        this.liveExpensive = liveExpensive;
    }

    public Date getHireDate() {
        return hireDate;
    }

    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }

    @Override
    public String toString() {
        super.toString();
        return "[Employee]" + "basicSalary=" + basicSalary + ", liveExpensive=" + liveExpensive + ", hireDate=" + hireDate ;
    }
    public abstract double getSalary();
    
}

