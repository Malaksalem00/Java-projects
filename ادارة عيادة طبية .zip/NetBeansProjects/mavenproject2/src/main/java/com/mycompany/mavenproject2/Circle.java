/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject2;

/**
 *
 * @author malak Kwaik
 */
public class Circle {
    private  double raduis;
   
     public Circle (double r){
         raduis=r;
     }
    public boolean equals(Circle c){
       boolean status;
       if(c.getRaduis()==raduis){
           status=true;
       }else
           status=false;
           return status ;  
    }
 public boolean greaterThan(Circle c){
     boolean status;
     if(c.getArea()>getArea()){
         status=true;
     }else
         status=false;
     return status;
 }
    public double getRaduis() {
        return raduis;
    }

    public void setRaduis(double r) {
        this.raduis = r;
    }
    public double getArea(){
        return Math.PI*raduis*raduis;
    }
   public String toString(){
       return "Circle with radius:"+raduis+"and area :"+getArea();
   }
   
   
}
