/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject10;

/**
 *
 * @author Hassan Kwaik
 */
public class BankAccount {
    private double balance;
    
    public BankAccount(){
        this.balance=0.0;
        
    }
 
    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
    public void deposit (double amount){
        balance+=amount;
    }
    public void withdrow(double amount){
    balance-=amount;
    }
    
}
