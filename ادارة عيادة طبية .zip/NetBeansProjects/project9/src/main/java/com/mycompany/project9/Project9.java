/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project9;

/**
 *
 * @author Hassan Kwaik
 */
public class Project9 {

    public static void main(String[] args) {
        RetailItem Item1 = new RetailItem("Jacket", 12, 59.95);
        RetailItem Item2  = new RetailItem("Smartphone", 40, 43.95);
        RetailItem Item3 = new RetailItem("Headphones", 20, 24.95);

       
        System.out.println("Item 1 Information:\n" + Item1.toString() + "\n");
        System.out.println("Item 2 Information:\n" + Item2.toString() + "\n");
        System.out.println("Item 3 Information:\n" + Item3.toString() + "\n");
    }


}
