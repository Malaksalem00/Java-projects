/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project7;

/**
 *
 * @author Hassan Kwaik
 */
public class Account {
    private double balance;  //الرصيد
    private double interestRate;//معدل الفائدة
    
    public Account(double in) {
        balance = 0.0;
        interestRate = in;
    }
    
public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }
public void withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
        }
    }
public double calculateInterest() {
        return balance * interestRate;
    }
public double getBalance() {
        return balance;
    }
public double getInterestRate() {
        return interestRate;
    }

}
