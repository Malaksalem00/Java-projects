/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loops;

/**
 *
 * @author Hassan Kwaik
 */
public class Loops {

    public static void main(String[] args) {
       int i; 
       for( i=1;i<=5;i+=2)
       {
         System .out.print(i);
           System .out.println("*");   
       }
       /*int x=3;
       int y=3+x++;
       System.out.println("x="+x);
 System.out.println("y="+y);
         int x=5;
         System.out.println("x="+ ++x);
         System.out.println("x="+x);*/
       /*
       i=1;//initial value
       
       while(i<=5)
       {
           System .out.print(i);
           System .out.println("*");
         i++;
       }*/
    }
}
