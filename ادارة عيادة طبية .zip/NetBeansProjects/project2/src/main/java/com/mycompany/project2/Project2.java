/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.project2;

/**
 *
 * @author malak Kwaik
 */
public class Project2 {

    public static void main(String[] args) {
        Car c1 = new Car("BMW", "2024", 26000);
        c1.display();
        Car c2 = new Car("Ford Mustang", "2021", 24000);
        c2.display();
        c1.disacount(5);
        System.out.println("\nPrice after 5% discount on car 1:");
        c1.display();
        c2.disacount(7);
        System.out.println("\nPrice after 7% discount on car 2:");
        c2.display();
    }
    
}
