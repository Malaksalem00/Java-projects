/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.appjavaoop;

/**
 *
 * @author Hassan Kwaik
 */
public class Studant {

    private int id;
    private String name;
    private double grade;

    public void insert(int id, String name, double grade) {
        this.id = id;
        this.name = name;
        this.grade = grade;

    }

    public void updataGrade(double newGrade) {
        this.grade = newGrade;
    }

    public void display() {
        System.out.println("Id" + id + "Name:" + name + "grade:" + grade);
    }
}
