/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject8;

/**
 *
 * @author Hassan Kwaik
 */
public class Address {

    
    private String city;
    private String street;
    private int number;
     public Address(String city,String street,int num){
         this.city=city;
         this.street=street;
         this.number=num;
     }
     public Address ( Address A1){
        this(A1.city,A1.street ,A1. number);
         
//         city=A1.city;
//         street=A1.street;
//         number=A1.number;
     }
     
     
     
     
     
     
     
     
    // public Address copy(){
      // Address copyobject= new Address(city,street,number);
       //return copyobject;
     //}

    @Override
    public String toString() {
        return "Address{" + "city:" + city + ", street:" + street + ", number:" + number + '}';
    }
    
}
