/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.culcate;

import java.util.Scanner;
//Malak abu kwaik
//2320234786
public class Culcate {

    public static void main(String[] args) {
        double result;// the VAR store in the result

        for (;;) { // the sntax of infitity looping 
            Scanner input = new Scanner(System.in);
            System.out.println("  Choose one of this operation:");
            System.out.println("1. Addtion");
            System.out.println("2. Subtraction");
            System.out.println("3. Multiplication");
            System.out.println("4.Division");
            System.out.println("5. Exit");
            System.out.print("My Chooes : ");
            int UsreNum = input.nextInt(); // user enter type of operation from men
            if(UsreNum==5) // if the user enter 5 the looping is stoping .
            break;

            System.out.println("Enter the First Number :");
            double num1 = input.nextDouble(); // user enter the first number
            System.out.println("Enter the Secand Number :");
            double num2 = input.nextDouble(); // user enter the secand number


            switch (UsreNum) {
                case 1:
                    result = num1 + num2;
                    System.out.println("Result = " + result);
                    break;
                case 2:
                    result = num1 - num2;
                    System.out.println("Result = " + result);

                    break;
                case 3:
                    result = num1 * num2;
                    System.out.println("Result = " + result);

                    break;
                case 4:
                    if (num2 == 0) {
                        System.out.println("not division By zero ");
                        break;

                    }
                    result = num1 / num2;
                    System.out.println("Result = " + result);
                    break;

            }
            
        }
                System.out.println("Thank you!");

    }

}
