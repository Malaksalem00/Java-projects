/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.method;

import java.util.Scanner;

/**
 *
 * @author Hassan Kwaik
 */
public class Method {

    private static char n;
//  static int  sum( int a , int b ){
//    int result = a + b ;
//    return result;
//    }
   static void sumchr (int a , char b  ){
          double num1 = (int) a;
                  int num2  = (char)(int) b;
                  System.out.println(num1);
             System.out.println(num2);

                 
    }

    public static void main(String[] args) {
//        Scanner input = new Scanner(System.in);
//       
//        int num1,num2;
//        System.out.println("enter number1:");
//       num1=input.nextInt();
//       System.out.println("enter number2:");
//        num2=input.nextInt();
//        System.out.println("the sum = "+sum(num1, num2));
    }
}
