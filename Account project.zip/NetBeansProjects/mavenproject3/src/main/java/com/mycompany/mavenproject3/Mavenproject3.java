/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject3;

import java.util.Scanner;

/**
 *
 * @author Hassan Kwaik
 */
public class Mavenproject3 {

    public static void main(String[] args) {
        Scanner k=new Scanner (System.in);
        System.out.println("enter tne temperature");
        double f= k.nextDouble();
        Temperature t =new Temperature(f);
        System.out.println(t.getCelsius());
        System.out.println(t.getKelvin());
    }
}
