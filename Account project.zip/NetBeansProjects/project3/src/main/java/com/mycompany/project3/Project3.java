/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.project3;


import java.util.Scanner;

/**
 *
 * @author malak Kwaik
 */
public class Project3 {

    public static void main(String[] args) {
        Scanner k = new Scanner(System.in);
        Geometry g1 = new Geometry();
        int choice;
        do {
            System.out.println("Geometry Calculator");
            System.out.println("1.Calculator the Area of a Circle");
            System.out.println("2.Calculator the Area of a Rectangle");
            System.out.println("3.Calculator the Area of a Triangle");
            System.out.println("4.Calculator the Area of a Quit");
            System.out.println("Enter your choice(1-4)");
            choice = k.nextInt();
        
         switch (choice) {
            case 1:
                 System.out.println("Enter a raduis");
                 double r=k.nextDouble();
                 if(r!=-1){
                     System.out.println(Geometry.getCircleArea(r));
                 }break;
                 case 2:
                     System.out.println("Enter a length");
            int l = k.nextInt();
           System.out.println("Enter a width");
            int w = k.nextInt();
            if (w != -1 || l != -1) {
                System.out.println(Geometry.getRectangleArea(w, l));
                 }
                break;
                case 3:
                    System.out.println("Enter a Hight");
            int h = k.nextInt();
            System.out.println("Enter a Basic ");
            double b = k.nextDouble();
            if(h!=-1||b!=-1 ){
            System.out.println(Geometry.getTriangleArea(b, h));
            }break;
                case 4:
                    System.out.println("finish the progream ");
                   break;
            default:
                System.out.println("Enter your choice(1-4)");
                
        }    
//            
        } while (choice != 4);

    }

}
