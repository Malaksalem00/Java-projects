/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject8;

/**
 *
 * @author Hassan Kwaik
 */
public class Mavenproject8 {

    public static void main(String[] args) {
       Address A1=new Address("Gaza", "omar elmokhtar", 500);
       Address A2=new Address(A1);
      //Address A2;
        // A2 = A1.copy();
         System.out.println("Information of address1:\n" + A1.toString());
         System.out.println("Information of address2:\n :"+A1.toString() );
    }
}
