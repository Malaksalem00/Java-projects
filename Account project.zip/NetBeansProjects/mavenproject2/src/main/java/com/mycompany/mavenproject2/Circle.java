/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject2;

/**
 *
 * @author Hassan Kwaik
 */
public class Circle {
    private  double raduis;
    private  final double PI=3.14159;
     public Circle (double r){
         raduis=r;
     }
     public Circle (){
         raduis=0.0;
     }

    public double getRaduis() {
        return raduis;
    }

    public void setRaduis(double r) {
        this.raduis = r;
    }
    public double getArea(){
        return PI*raduis*raduis;
    }
   public double getDiameter(){
        return 2*raduis;
    }
   public double getCircumference(){
        return 2*PI*raduis;
    }
   
   
}
