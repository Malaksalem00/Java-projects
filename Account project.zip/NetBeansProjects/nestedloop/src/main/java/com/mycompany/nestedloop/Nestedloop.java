/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.nestedloop;

import java.util.Scanner;

/**
 *
 * @author Hassan Kwaik
 */
public class Nestedloop { 

/**
 * @param name
 */
public static void printMsg(String name){
System.out.println(" hello"+name+"to java");
}
    public static void main(String[] args) {
     Scanner input=new Scanner(System.in);
     System.out.print("Enter your name");
     String name=input.next();
printMsg(name);

}
}