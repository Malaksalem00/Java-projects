/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.mavenproject4;

import java.util.Scanner;

/**
 * ملك سالم خليل ابو كويك 
 * 2320234786:الرقم الجامعي
 */
public class Mavenproject4 {

    public static void main(String[] args) {
        Scanner k = new Scanner(System.in);
        Distance d1 = new Distance();
        d1.display();
        System.out.println("Enter feet  for d2: ");
        int f = k.nextInt();
        System.out.println("Enter  inches for d2: ");
        int i = k.nextInt();
        Distance d2 = new Distance(f, i);
        d2.display();
    }
}
