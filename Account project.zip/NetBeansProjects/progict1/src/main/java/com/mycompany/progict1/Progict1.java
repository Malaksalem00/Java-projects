/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.progict1;
import java.util.Scanner;

public class Progict1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        Scanner in = new Scanner(System.in);
        String firstName , lastName;
        System.out.println(" First name:");
        firstName =in.nextLine(); 
        System.out.println(" Last name:");
        lastName =in.nextLine();
        String fullName = firstName +" "+ lastName;
     
        System.out.println("Full name:" + fullName) ;
        
    }
}
