/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project11;

/**
 *
 * @author Hassan Kwaik
 */
public class TestScore {
     private double score1;
    private double score2;
    private double score3;
   public TestScore(double score1, double score2, double score3) {
        this.score1 = score1;
        this.score2 = score2;
        this.score3 = score3;
    }

    
    public void setScore1(double score1) {
        this.score1 = score1;
    }

    public void setScore2(double score2) {
        this.score2 = score2;
    }

    public void setScore3(double score3) {
        this.score3 = score3;
    }

    
    public double getScore1() {
        return score1;
    }

    public double getScore2() {
        return score2;
    }

    public double getScore3() {
        return score3;
    }

   
    public double calculateAverage() {
        return (score1 + score2 + score3) / 3;
    }

   
    @Override
    public String toString() {
        return "Test Score 1: " + score1 + "\n" +
               "Test Score 2: " + score2 + "\n" +
               "Test Score 3: " + score3 + "\n" +
               "Average Score: " + calculateAverage();
    }

}
