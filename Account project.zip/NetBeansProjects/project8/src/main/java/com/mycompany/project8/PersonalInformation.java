/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project8;

/**
 *
 * @author Hassan Kwaik
 */
public class PersonalInformation {
    private String address;
    private String name;
    private int age;
    private String phoneNumber;
    
     public PersonalInformation(String n, String ad, int ag, String phN) {
        name = n;
        address = ad;
        age = ag;
        phoneNumber = phN;
        
    }

    public String getName() {
        return name;
    }

    public void setName(String n) {
        name = n;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String ad) {
        address = ad;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int ag) {
        age = ag;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phN) {
        phoneNumber = phN;
    }

@Override
    public String toString() {
        return "Name: " + name + "\n" +
               "Address: " + address + "\n" +
               "Age: " + age + "\n" +
               "Phone Number: " + phoneNumber;
    }
}
