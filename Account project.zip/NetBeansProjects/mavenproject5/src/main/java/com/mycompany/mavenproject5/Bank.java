/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject5;

/**
 *
 * @author Hassan Kwaik
 */
public class Bank {
    private String accountType;
  private double balance;
  private double intresRate;
  public Bank(double balance,double interestRate,String accountType){
   this.balance=balance;
this.intresRate=interestRate;
this.accountType=accountType;
  }
  public void deposit(double amount){//ايداع الاموال
      if (amount>0){
          balance+=amount;
      }
  }
      public void withdrow(double amount){ //سحب الاموال
          if(amount >0&&amount<=balance){
              balance-=amount;
          }   
      }
      public double calculateInterest(){
          return balance*intresRate;
      }
       public void printAccountDetails(){
           System.out.println("Balance ٍ:is "+balance);
           System.out.println("InterestEarned :$"+calculateInterest());
       }
     
       
       
}
