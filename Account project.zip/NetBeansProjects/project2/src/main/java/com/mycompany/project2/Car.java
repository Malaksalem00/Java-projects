/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project2;

/**
 *
 * @author Hassan Kwaik
 */
public class Car {
    private String model;
    private String year;
    private  double price;
      
    public Car(String m,String y,double p){
        model=m;
        year=y;
        price=p;
        if (price>0){
            price=p;
        }else{
        price=0;
        }
        
    }

    public String getModel() {
        return model;
    }

    public void setModel(String m) {
        model = m;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String y) {
        year = y;
    }

    public double getPrice() {
        
        return price;
    }

    public void setPrice(double p) {
        if (p > 0) {
            price = p;
        }
    }
    public void disacount( double d){
     price=price-(price*d/100);
    }
     public void display() {
        System.out.println("Model: " + model + ", Year: " + year + ", Price: $" + price);
     }
        
    
    
}
