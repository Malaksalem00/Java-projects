/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject10;

import java.util.Scanner;

/**
 *
 * @author Hassan Kwaik
 */
public class Mavenproject10 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
//        BankAccount account = new BankAccount();
//        account.setBalance(1000);
//        account.deposit(500);
//        account.withdrow(200);
//        System.out.println("Now your balance is "+ account.getBalance());
        BankAccount[] accounts =new BankAccount[3];
        double balance;
        Scanner k =new Scanner(System.in);
        for ( int i=0;i<accounts.length;i++){
            System.out.println("Enter the balance for account " + (i+1)+":");
            balance=k.nextDouble();
            accounts[i]=new BankAccount();
            accounts[i].setBalance(balance);
        }
        for (int i = 0;i <accounts.length;i++){
            System.out.println("Account "+(i+1)+ ": $"+ accounts[i].getBalance());
        }
    }
}
