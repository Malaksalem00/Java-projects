/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.constuctor1;

/**
 *
 * @author Hassan Kwaik
 */
public class Employee1 {
    private String name;
    private int id;
    private String department;
    private String position;
    
    public Employee1(String n , int i ,String d ,String p){
        name=n;
         id=i;
        department=d;
        position=p;
        
    }
    public Employee1(String n , int i ){
        name=n;
         id=i;
         department="";
       
    }
    public Employee1(){
        name="";
         id=0;
         department="";
         position="";
       
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }
    
}
