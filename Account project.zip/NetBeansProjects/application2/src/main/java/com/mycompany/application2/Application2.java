/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.application2;

import java.util.Scanner;

/**
 *
 * @author Hassan Kwaik
 */
public class Application2 {

//  static int min(int n1, int n2, int n3) {
//      int min = n1;
//        if (min > n2) {
//            min = n2;
//        }
//        if (min > n3) {
//            min = n3;
//        }
//        return min;
//    }
//   static int avareg(int n1,int n2, int n3){
//       int sum= n1+n2+n3;
//       int result=sum/3;
//       return result;
//   }
//
  public static void main(String[] args) {
      
//       System.out.println("Enter 3 number");  
//       Scanner input=new Scanner(System.in);
//       int num1,num2,num3;
//       System.out.println("Enter number 1:");
//       num1=input.nextInt();
//       System.out.println("Enter number 2:"); 
//        num2=input.nextInt();
//       System.out.println("Enter number 3:");
//        num3=input.nextInt();
////        System.out.println("the avareg is :"+ (avareg(num1, num2, num3)));
        
   }
}
//        System.out.println("Enter 3 number");
//        Scanner input = new Scanner(System.in);
//        int num1, num2, num3;
//
//        System.out.println("Enter number one");
//        num1 = input.nextInt();
//        System.out.println("Enter number two");
//        num2 = input.nextInt();
//        System.out.println("Enter number three");
//        num3 = input.nextInt();
//
//        System.out.println("the smallest among number is :"+ (min(num1, num2, num3)));
//    }


