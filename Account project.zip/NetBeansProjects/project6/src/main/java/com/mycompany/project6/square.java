/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project6;

/**
 *
 * @author Hassan Kwaik
 */
public class square {
     private double sideLengh;
     public double getArea(){
         return sideLengh*sideLengh;
     }
     public double getSideLength(){
         return sideLengh;
     }
     public square(){
         sideLengh=0.0;
     }
     public square(double sideLength) {
         this.sideLengh=sideLengh;
     }
     
}
