/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project10;

import java.util.Scanner;

/**
 *
 * @author Hassan Kwaik
 */
public class Project10 {

    public static void main(String[] args) {
        Scanner k = new Scanner(System.in);

        
        System.out.print("Enter employee's name: ");
        String name = k.nextLine();

        System.out.print("Enter employee's ID number: ");
        int idNumber = k.nextInt();

       
        Payroll employee = new Payroll(name, idNumber);

       
        System.out.print("Enter hourly pay rate: $");
        double hourlyPayRate = k.nextDouble();
        employee.setHourlyPayRate(hourlyPayRate);

        System.out.print("Enter number of hours worked: ");
        double hoursWorked = k.nextDouble();
        employee.setHoursWorked(hoursWorked);

        // عرض بيانات الموظف والأجر الإجمالي
        System.out.println("\nEmployee Payroll Information:\n");
        System.out.println(employee.toString());

        
    }

    
}
