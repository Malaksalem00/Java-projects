/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject9;

/**
 *
 * @author Hassan Kwaik
 */
public class Courses { 
    
    
    private  String courseName;
    private int level;
    private TextBook textBook;
     public Courses(String name,TextBook text ){
    courseName=name;
    textBook=new TextBook(text);
     }
     
     public  String getCourseName(){
     return courseName;
     }
     
     
     public TextBook getTextbok(){
       return new TextBook (textBook);
   }

    @Override
    public String toString() {
       String str = "CourseName :"+courseName +
                "\nTextBook :"+textBook ;
                
        return str;
    }
     
}
