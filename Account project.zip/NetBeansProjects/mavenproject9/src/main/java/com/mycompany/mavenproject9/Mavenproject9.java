/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject9;

/**
 *
 * @author Hassan Kwaik
 */
public class Mavenproject9 {

    public static void main(String[] args) {
       TextBook myTextBook=new TextBook("Data Mining And Analys is ","Mohammad Zaki","Combridge");
       Courses myCourses= new Courses("Data Mining", myTextBook);
        System.out.println(myCourses);
    }
}
