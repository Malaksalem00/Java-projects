/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;

/**
 *
 * @author Hassan Kwaik
 */
public class Employee2 {
    private String name;
    private int id;
    private String department;
    private String position;
    
    public Employee2(String n , int i ,String d ,String p){
        name=n;
         id=i;
        department=d;
        position=p;
        
    }
    public Employee2(String n , int i ){
        name=n;
         id=i;
         department="";
         position="";
       
    }
    public Employee2(){
        name="";
         id=0;
         department="";
         position="";
       
    }

   

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    @Override
    public String toString() {
        return"Name: " + name + "\n" +
               "ID Number: " + id + "\n" +
               "Department: " + department + "\n" +
               "Position: " + position; 
    }

   
//    public void displayEmployeeInfo() {
//        System.out.println("Name: " + name);
//        System.out.println("ID Number: " + id);
//        System.out.println("Department: " + department);
//        System.out.println("Position: " + position);
//    }
    
}


